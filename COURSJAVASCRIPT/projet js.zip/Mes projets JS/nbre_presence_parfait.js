var tab=[];
for(i=0;i<5;i++)
{
    var nbre=prompt("Remplissez votre tableau")
    tab.push(nbre);
}

som_premier=0;
for(i=0;i<tab.length;i++)
{
   if(nbre_premier(tab[i]))
   {
som_premier+=1;
   }
   
}
if(som_premier!=0)
{
    alert("il ya "+som_premier+" nbre premier dans votre tableau");
}
 else
 {
 
 alert(" -1 ");
}
 function nbre_premier(nombre)
 {
     if(nombre<=1)
     {
         return false;
 }
 
     for (var i=2;i<nombre;i++)  
         { 
             if(nombre%i===0)
             {
                 return false; 
             }
             
             }
              return true;
         }

