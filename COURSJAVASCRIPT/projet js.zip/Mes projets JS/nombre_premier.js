var nbre=prompt("Entrer un nombre");
nbre_premier(nbre);

function nbre_premier(nombre)
{
    if(nombre<=1)
    {
        alert("false");
        return;
}

    for (var i=2;i<nombre;i++)  
        { 
            if(nombre%i===0)
            {
                alert("false");  
                return;
            }
        }
            
                alert("true")
            
            
       
        //alert("true");
}

