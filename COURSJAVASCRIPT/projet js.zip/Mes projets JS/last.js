function nbre_premier(nombre)
{
    if(nombre<=1)
    {
        
        return false;
}

    for (var i=2;i<nombre;i++)  
        { 
            if(nombre%i===0)
            {
                 
                return false; 
            }
            
            }
             return true;
        }

        function parfait(nbre){
            var som_div=0;
        for(var i=1;i<nbre;i++){
            if(nbre % i=== 0) {
                som_div += i;
            }
        }
        return nbre === som_div;
        }
        
        
        var x=parseInt(prompt("veuillez sasir un entier:"));
        if (isNaN(x)) {
           alert("Veuillez saisir un nombre entier valide.");
        } else {
            if (nbre_premier(x)) {
                alert(x + " est un nombre premier.");
            } else if (parfait(x)) {
                alert(x + " est un nombre parfait.");
            } else {
                alert(x + " n'est ni un nombre premier ni un nombre parfait.");
            }
        }
