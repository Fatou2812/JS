function parfait(nbre){
    var som_div=0;
for(var i=1;i<nbre;i++){
    if(nbre % i=== 0) {
        som_div += i;
    }
}
return nbre === som_div;
}

var nombre=prompt("Entrer un nombre");
if(parfait(parseInt(nombre)))
{
alert("est parfait")
}
else{
    alert("n'est pas parfait")
}