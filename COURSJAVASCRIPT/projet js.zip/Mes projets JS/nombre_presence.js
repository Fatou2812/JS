function nbre_presence(tableau,val)
{
    var cpte=0;
    tableau.forEach(element => {
        if(element===val)
        {
            cpte++;
        }
    });
    
    return cpte; 
}
  var tab=[];

  var taille=prompt("tableau de combien d'entier?")
  for(i=0;i<taille;i++)
  {
  var nbre=prompt("Remplissez votre tableau")
  tab.push(nbre);
  }
  var val=prompt("Quel est votre val");
  var result=nbre_presence(tab,val)
  if(cpte=0)
  {
    alert("-1")
   
  }
  else{
    alert("le nombre de presence de "+val+" est "+result)
  }
       
