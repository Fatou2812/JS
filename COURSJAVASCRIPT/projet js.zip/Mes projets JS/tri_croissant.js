var tab=[];
var taille=prompt("tableau de combien d'entier?")
for(i=0;i<taille;i++)
{
var nbre=prompt("Remplissez votre tableau")
tab.push(nbre);
}

for(i=0;i<taille;i++)
{
    document.getElementById("tableau1").innerHTML+=tab[i]+'<br>'
    
}

tab.sort();

for(i=0;i<taille;i++)
{
    document.getElementById("tableau2").innerHTML+=tab[i]+'<br>'
    
}