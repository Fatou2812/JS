var tab=[];
var taille=prompt("tableau de combien d'entier?")
for(i=0;i<taille;i++)
{
var nbre=prompt("Remplissez votre tableau")
tab.push(nbre);
}

for(i=0;i<taille;i++)
{
    document.getElementById("t").innerHTML+=tab[i]+'<br>'
    
}